# DX:Eternity Development Log (DevilutionX 1.5.4 Fork)

**Base Commit:** `9f30593b4c2e706d6d6a66edfbc3aa6ada8861b4` (DevilutionX 1.5.4)  
**Target Architecture:** Windows 64-bit (`x86_64-w64-mingw32`, static/self-contained `dx-eternity.exe`)

---

## Phase 1: Quality of Life & Endgame Loop (Completed & Verified)

### 1.1 Town Shortcuts Open in Single Player (Nightmare & Hell)
- **File:** `Source/levels/trigs.cpp` — `IsWarpOpen(dungeon_type)`
- **Change:** In Single Player (`!gbIsMultiplayer`), returns `true` unconditionally for `DTYPE_CATACOMBS`, `DTYPE_CAVES`, and `DTYPE_HELL`, opening the town shortcuts to Catacombs (Level 5), Caves (Level 9), and Hell (Level 13) right from the start of a game session.

### 1.2 Endless Single Player Session & Diablo Loot Drop
- **File:** `Source/monster.cpp` — `DiabloDeath(Monster &)` & `MonsterDeath(Monster &, ...)`
- **Change:**
  - `DiabloDeath()`: Changed `gbProcessPlayers = false` to `gbProcessPlayers = !gbIsMultiplayer` so Single Player movement/input is not frozen when Diablo dies.
  - `MonsterDeath()`: At `monster.var1 == 140` in Single Player (`!gbIsMultiplayer`), skips `PrepDoEnding()`, spawns `MissileID::DiabloApocalypseBoom` at Diablo's tile, clears `dMonster[x][y] = 0`, marks `monster.isInvalid = true`, and updates monster relations (`M_UpdateRelations(monster)`).
- **File:** `Source/items.cpp` — `SpawnItem(Monster &, ...)`
- **Change:** Treats `MT_DIABLO` alongside unique monsters (`monster.isUnique() || monster.type().type == MT_DIABLO`) so Diablo drops loot (`uper = 15`, `RndUItem(monster)`) without applying the `-15` qlvl penalty in classic Diablo 1 mode.

---

## Phase 2: Custom Unique Weapon (`Kadi's Fury`) & FastWalk Fix (Completed & Verified)

### 2.1 Item Effect & Unique ID Definitions
- **File:** `Source/itemdat.h`
  - Added `FastWalk = 1 << 7` to `enum class ItemSpecialEffectHf : uint8_t`.
  - Added `IPL_FASTWALK` to `item_effect_type`.
- **File:** `Source/items.h`
  - Added `UITEM_KADISFURY = 110` to `_unique_items`.

### 2.2 `Kadi's Fury` Unique Item Specification
- **File:** `Source/itemdat.cpp` — `UniqueItemList[]`
  - Added `Kadi's Fury` at index `110` (`UITEM_KADISFURY`):
    - Base Type: `UITYPE_BROADSWR` (Broad Sword), `qlevel = 1`, `maxValue = 25000`
    - Affix 1: `IPL_TOHIT` (`+100% To Hit`)
    - Affix 2: `IPL_DMG_PERC` (`+175% Damage`)
    - Affix 3: `IPL_FASTATTACK` (`4` = Fastest Attack)
    - Affix 4: `IPL_LIGHTDAM` (`4` to `16` Lightning Damage)
    - Affix 5: `IPL_FASTWALK` (`faster walk`)
    - Affix 6: `IPL_ALLRES` (`-30%` to All Resistances)

### 2.3 Affix Application, Unique Availability & Save/Load Persistence in Classic D1 Mode
- **File:** `Source/items.cpp`
  - `SaveItemPower()`:
    - Removed `std::max(r, 0)` clamping on `IPL_ALLRES` so negative resistance penalties (`-30%`) apply properly.
    - Added `case IPL_FASTWALK: item._iDamAcFlags |= ItemSpecialEffectHf::FastWalk; break;`.
  - `IsUniqueAvailable(int i)`: Allowed `i == UITEM_KADISFURY` even when `!gbIsHellfire`.
  - `CheckUnique()` & `DebugSpawnUniqueItem()`: Changed `if (!IsUniqueAvailable(j)) break;` to `continue;` so scanning past unavailable Hellfire items reaches `UITEM_KADISFURY` (index 110).
  - `GetUniqueItem()` & `SetupAllItems()`: Stored `uid` in `item._iSeed` for `UITEM_KADISFURY` and allowed `RecreateItem()` (`SetupAllItems`) to restore `GetUniqueItem(item, iseed)` when `recreate && iseed == UITEM_KADISFURY`, preserving the item across `PackItem`/`UnPackItem` in classic Diablo 1 mode.
  - `SpawnUnique()`: Initialized `item._iCreateInfo = curlv` and allowed `uid == UITEM_KADISFURY` to spawn on all difficulties (`DIFF_NORMAL`, `DIFF_NIGHTMARE`, `DIFF_HELL`).
  - `CalcPlrItemVals()`: Ensured `item._iDamAcFlags |= ItemSpecialEffectHf::FastWalk` is set when `item._iUid == UITEM_KADISFURY` or `item._iSeed == UITEM_KADISFURY`.
  - `PrintItemPower()`: Added `case IPL_FASTWALK: return _("faster walk");`.
- **File:** `Source/loadsave.cpp`
  - `LoadItemData()`: Classic Diablo 1 saves (`!gbIsHellfireSaveGame`) do not serialize `_iDamAcFlags` in the 36-byte item struct and zero it on load. Added restoration of `item._iDamAcFlags = ItemSpecialEffectHf::FastWalk` whenever `item._iMagical == ITEM_QUALITY_UNIQUE && (item._iUid == UITEM_KADISFURY || item._iSeed == UITEM_KADISFURY)`.
  - `RemoveInvalidItem()`: Exempted `UITEM_KADISFURY` from the `!gbIsHellfire && item._iDamAcFlags != ItemSpecialEffectHf::None` anti-cheat strip during level transitions and game loads.
- **File:** `Source/player.cpp`
  - `StartWalkAnimation()`: Checked `HasAnyOf(player.pDamAcFlags, ItemSpecialEffectHf::FastWalk)` plus an explicit `player.InvBody` fallback check for `FastWalk` / `UITEM_KADISFURY`, adding `skippedFrames += 3` to walk animations **only outside of Town** (`leveltype != DTYPE_TOWN`) so it does not stack uncontrollably with `Run in Town`.

---

## Phase 3: Nest & Crypt Dungeon Staircase Transitions & Town Walk Fix (Current Build)

*(Note: Extended Mode & isolated saves/stash were scrapped per user direction.)*

### 3.1 Disable `Kadi's Fury` Walk Speed Bonus in Town
- **File:** `Source/player.cpp` — `StartWalkAnimation()`
- **Change:** Gated the `FastWalk` check and `skippedFrames += 3` bonus behind `if (leveltype != DTYPE_TOWN)` so Town movement uses standard walk/Run-in-Town speed without overspeeding.

### 3.2 Remove Temporary Butcher Drop for `Kadi's Fury`
- **File:** `Source/monster.cpp` — `SpawnLoot()`
- **Change:** Removed the temporary `if (monster.type().type == MT_CLEAVER) SpawnUnique(UITEM_KADISFURY, ...)` block; `Kadi's Fury` now drops naturally via standard unique item generation.

### 3.3 Caves L12 <-> Nest L17 & Hell L14 <-> Crypt L21 Staircase Transitions
- **File:** `Source/levels/drlg_l3.cpp` — `PlaceCaveStairs()`
  - Placed a second `L3DOWN` ("stairs down") staircase miniset on Caves Level 12 (`currlevel == 12`), recorded its mega-tile origin in `L3AltStairsPos`, and positioned the player view at `position->megaToWorld() + Displacement { 3, 1 }` when returning up from Nest Level 17 (`entry == ENTRY_TWARPDN || entry == ENTRY_TWARPUP`).
- **File:** `Source/levels/drlg_l4.cpp` — `PlaceStairs()`
  - Placed a second `L4DSTAIRS` ("stairs down") staircase miniset on Hell Level 14 (`currlevel == 14`), recorded its mega-tile origin in `L4AltStairsPos`, and positioned the player view at `position->megaToWorld() + Displacement { 7, 5 }` when returning up from Crypt Level 21 (`entry == ENTRY_TWARPDN || entry == ENTRY_TWARPUP`).
- **File:** `Source/levels/trigs.cpp`
  - `InitL3Triggers()`: On Caves Level 12 (`currlevel == 12`), distinguished the second `dPiece == 167` staircase via `WorldTileRectangle { L3AltStairsPos.megaToWorld(), { 6, 6 } }.contains({ i, j })` and set its trigger to `_tmsg = WM_DIABTOWNWARP; _tlvl = 17;` ("Down to Hive").
  - `InitL4Triggers()`: On Hell Level 14 (`currlevel == 14`), distinguished the second `dPiece == 119` staircase via `WorldTileRectangle { L4AltStairsPos.megaToWorld(), { 10, 10 } }.contains({ i, j })` and set its trigger to `_tmsg = WM_DIABTOWNWARP; _tlvl = 21;` ("Down to Crypt").
  - `InitHiveTriggers()`: Set Nest Level 17 top staircase (`dPiece == 79`) trigger to `_tmsg = WM_DIABTWARPUP; _tlvl = 12;` (Up to Caves Level 12).
  - `InitCryptTriggers()`: Set Crypt Level 21 top staircase (`dPiece == 183`) trigger to `_tmsg = WM_DIABTWARPUP; _tlvl = 14;` (Up to Hell Level 14).
  - `ForceL3Trig()`, `ForceL4Trig()`, `ForceHiveTrig()`, `ForceCryptTrig()`: Matched `L3DownList` and `L4DownList` triggers by proximity (`dx < 4 && dy < 4`) so hovering either down-staircase on Caves L12 or Hell L14 displays the corresponding tooltip (`"Down to level 13"` vs `"Down to Hive"`, `"Down to level 15"` vs `"Down to Crypt"`) and snaps the cursor to the right staircase.
  - `CheckTriggers()`: Updated `case WM_DIABTWARPUP:` to pass `trigs[i]._tlvl` instead of hardcoded `0` to `StartNewLvl()`.
- **File:** `Source/player.cpp` — `StartNewLvl()`
  - In `case WM_DIABTWARPUP:`, guarded `MyPlayer->pTownWarps |= 1 << (leveltype - 2);` behind `if (lvl == 0)` so ascending from Nest L17 to Caves L12 or Crypt L21 to Hell L14 does not corrupt town warp flags.
- **File:** `Source/diablo.cpp` & `Source/engine/assets.cpp`
  - Set `giNumberOfLevels = 25` and enabled asset lookup fallback to `hellfire.mpq`/`hf*.mpq` after `diabdat.mpq` so Nest (17–20) and Crypt (21–24) tilesets, monsters, and cutscenes load seamlessly even when playing a classic Diablo campaign.

### 3.4 Hive & Crypt Save/Load Support in Classic Diablo Mode
- **File:** `Source/loadsave.cpp` & `Source/pfile.cpp`
  - Removed the `if (!gbIsHellfire && IsAnyOf(leveltype, DTYPE_NEST, DTYPE_CRYPT)) app_fatal(_("Player is on a Hellfire only level"));` guard in `LoadGame()`.
  - Kept the runtime global `giNumberOfLevels = 25` across `LoadGame()`, `SaveGameData()`, and `pfile_ui_save_create()` so `pfile.cpp` (`RenameTempToPerm`, `pfile_remove_temp_files`, `GetFileName`) properly manages `templ17`–`templ24` and `perml17`–`perml24` level files inside `.sv` save archives.
  - Preserved 100% binary compatibility with existing classic Diablo (`"RETL"`) `.sv` files by reading/writing `numSavedLevels = gbIsHellfire ? 25 : 17` inside the fixed-layout `"game"` stream (`LoadGame`, `SaveGameData`, `LoadPlayer`, `SavePlayer`), while persisting extended level seeds (`glSeedTbl[17..24]`), visited flags (`_pLvlVisited[17..24]`), and `pDungMsgs2` in an auxiliary `"extlevels"` save archive record (`SaveExtLevels` / `LoadExtLevels`), with deterministic seed fallback for pre-existing saves.

### 3.5 Audio Lock Contention, Projectile SFX & Balrog Flame FPS Drop Fix
- **Build Configuration (`CMAKE_BUILD_TYPE=Release`):**
  - Configured the CMake/Ninja Windows 64-bit cross-compile build with `-DCMAKE_BUILD_TYPE=Release` (`-O3 -DNDEBUG -flto=auto`), enabling full compiler optimization and link-time optimization across `libdevilutionx`, `SDL_audiolib`, `dr_wav`, and `speex_resampler` (which previously defaulted to an unoptimized `-O0` build when `CMAKE_BUILD_TYPE` was unset).
- **File:** `Source/player.cpp`
  - `DoWalk()`, `DoAttack()`, `DoRangeAttack()`: Added `player.AnimInfo.tickCounterOfCurrentFrame == 0` checks to all frame-based sound (`PS_WALK1`, `PS_SWING`) and attack/arrow triggers so multi-tick animation frames (`ticksPerFrame > 1`) only fire once on the initial tick of the action frame.
- **File:** `Source/monster.cpp`
  - `MonsterAttack()`, `MonsterRangedAttack()`, `MonsterSpecialAttack()`, `MonsterSpecialStand()`: Added `monster.animInfo.tickCounterOfCurrentFrame == 0` guards to all frame-based attack, ranged projectile, and special sound triggers (matching `MonsterRangedSpecialAttack()`), preventing multi-tick sound and projectile spam.
- **File:** `Source/missiles.cpp`
  - `ProcessInfernoControl()`: Passed `missile.var3 == 0 ? std::optional<_sfx_id> {} : std::optional<_sfx_id> { SFX_NONE }` to `AddMissile(..., MissileID::Inferno, ...)` so Balrog flame breath (`MissileID::InfernoControl`) only plays `LS_SPOUTSTR` once on the initial parent flame spawn (`var3 == 0`) rather than spawning overlapping 2-second loop streams on every child flame segment.
  - `SpawnLightning()`: Throttled `MissileID::Lightning` / `ThinLightning` child segments so `LS_LNING1` plays only on the initial segment spawn (`isFirstSegment`) rather than on every tile crossed by `LightningControl`.
- **File:** `Source/effects.cpp`, `Source/engine/sound.cpp` & `Source/utils/soundsample.h`
  - `PlaySfxLoc()`: Removed the `pSnd->start_tc = 0` reset for `psfx` `0..3` (`PS_WALK1`, `PS_BFIRE`, `PS_TMAG`, `PS_SWING`) that bypassed `snd_play_snd()`'s 80ms debounce window.
  - `PrivSoundInit()` & `sound_file_load()`: Preloaded Hellfire sound effects when present even in classic Diablo mode so Nest/Crypt combat SFX do not lazy-load from MPQ archives mid-combat.
  - `DuplicateSound()` & `SoundSample::MatchesData()`: Pooled finished duplicate `SoundSample` streams by shared audio buffer (`file_data_.get()`) so overlapping projectile SFX reuse already-opened `Aulib::Stream` and `ResamplerSpeex` instances without heap reallocation or `SDL_LockAudioDevice` stream-open/close thrashing; removed the SDL audio callback's `SetFinishCallback` mutex lock; added a 15ms global duplicate spawn interval and capped active duplicate streams at `MaxActiveDuplicateSounds = 8`.

---

## Phase 4: Pure Classic Diablo Loot Filter & Hell Diablo ~2% `Kadi's Fury` Drop

### 4.1 Hell Diablo ~2% `Kadi's Fury` Boss Drop
- **File:** `Source/monster.cpp` — `SpawnLoot()`
  - Added a 1-in-50 (`GenerateRnd(50) == 0`, `2%`) drop roll when `monster.type().type == MT_DIABLO && sgGameInitInfo.nDifficulty == DIFF_HELL` to spawn `UITEM_KADISFURY` alongside Diablo's normal loot drop.
- **File:** `Source/items.cpp` — `CheckUnique()`
  - Excluded `UITEM_KADISFURY` from random world unique rolls (`if (!recreate && j == UITEM_KADISFURY) continue;`) so `Griswold's Edge` remains the standard unique Broad Sword world drop while `Kadi's Fury` is exclusive to Hell Diablo (and still recreates cleanly on save/load when `recreate == true`).

### 4.2 Pure Classic Diablo Loot in Nest & Crypt
- **File:** `Source/items.cpp` — `IsItemAvailable()` & `InitItems()`
  - Blocked all Hellfire oils (`IMISC_OILFIRST..IMISC_OILLAST`), runes (`IMISC_RUNEFIRST..IMISC_RUNELAST`), and Hellfire-only base items (`i > 160`) when `!gbIsHellfire`.
  - Enabled floor potion initialization (`AddInitItems()`) on Nest and Crypt levels (`currlevel > 0 && currlevel != 16`) and gated `SpawnNote()` behind `gbIsHellfire`.
- **File:** `Source/monster.cpp` — `SpawnLoot()`
  - Updated `UniqueMonsterType::Defiler` to drop a standard boss item (`SpawnItem(monster, ...)`) instead of the Hellfire-only `Cathedral Map` (`SpawnMapOfDoom`) when `!gbIsHellfire`.

### 4.3 Additional Hell Diablo ~2% Exclusive Uniques (`Apostate's Crook` & `Loxley's Bend`)
- **File:** `Source/items.h` & `Source/itemdat.h`
  - Added `UITEM_APOSTATESCROOK = 111` and `UITEM_LOXLEYSBEND = 112` to `enum _unique_items`.
  - Added `IPL_MAXDAM` to `enum item_effect_type` for flat maximum damage bonuses on unique weapons.
- **File:** `Source/itemdat.cpp` — `UniqueItems[]`
  - Added **Apostate's Crook** (`UITYPE_WARSTAFF`, War Staff base: Damage `8–16`, Durability `75`):
    - `+2 to All Spell Levels` (`{ IPL_SPLLVLADD, 2, 2 }`)
    - `+40 to Magic` (`{ IPL_MAG, 40, 40 }`)
    - `+80 to Maximum Mana` (`{ IPL_MANA, 80, 80 }`)
    - `Damage Reduced by 8` (`{ IPL_GETHIT, 8, 8 }`)
    - `-50 to Armor Class` (`{ IPL_AC_CURSE, 50, 50 }`)
    - `Resist All: -30%` (`{ IPL_ALLRES, -30, -30 }`)
  - Added **Loxley's Bend** (`UITYPE_WARBOW`, Long War Bow base: Damage `1–14`, Durability `60`):
    - `Knocks Target Back` (`{ IPL_KNOCKBACK }`)
    - `+40 to Dexterity` (`{ IPL_DEX, 40, 40 }`)
    - `+30 to Maximum Damage` (`{ IPL_MAXDAM, 30, 30 }`)
    - `Steals 5% Mana` (`{ IPL_STEALMANA, 5, 5 }`)
    - `-40% Light Radius` (`{ IPL_LIGHT_CURSE, 4, 4 }`)
    - `-50 to Maximum Life` (`{ IPL_LIFE_CURSE, 50, 50 }`)
- **File:** `Source/items.cpp`
  - Handled `IPL_MAXDAM` in `SaveItemPower()` (`item._iMaxDam += r;`) and `PrintItemPower()` (`"{:+d} to maximum damage"`).
  - Registered `UITEM_APOSTATESCROOK` and `UITEM_LOXLEYSBEND` alongside `UITEM_KADISFURY` in `CheckUnique()` (excluded from random world unique drops when `!recreate`), `GetUniqueItem()`, `SetupAllItems()`, `IsUniqueAvailable()`, and `SpawnUnique()`.
- **File:** `Source/missiles.cpp` — `MonsterMHit()`
  - Enabled `StealMana3`, `StealMana5`, `StealLife3`, and `StealLife5` on physical arrow hits (`missileData.isArrow() && damageType == DamageType::Physical`) so `Loxley's Bend` steals 5% mana on bow attacks.
- **File:** `Source/monster.cpp` — `SpawnLoot()`
  - Added independent `GenerateRnd(50) == 0` (`2%`) drop rolls for `UITEM_APOSTATESCROOK` and `UITEM_LOXLEYSBEND` alongside `UITEM_KADISFURY` when `monster.type().type == MT_DIABLO && sgGameInitInfo.nDifficulty == DIFF_HELL`.

---

## Phase 5: Female Barbarian Class (Rogue Visual & Audio Assets)

### 5.1 Character Creation & Female UI Portrait
- **File:** `Source/DiabloUI/hero/selhero.cpp` — `SelheroListSelect()` & `SelheroGenerateName()`
  - Enabled `HeroClass::Barbarian` in character creation whenever `!gbIsSpawn` (without requiring `diablo.ini` test flags or `hfbarb.mpq`).
  - Updated default prefill names for `HeroClass::Barbarian` to female warrior/shieldmaiden names (`"Sonya"`, `"Freya"`, `"Boudica"`, `"Astrid"`, `"Valkyrie"`, etc.).
- **File:** `Source/DiabloUI/diabloui.cpp` — `LoadHeros()`
  - Mapped `ArtHeroPortraitOrder[static_cast<std::size_t>(HeroClass::Barbarian)] = 1` and `ArtHeroOverrides[Barbarian]` to `HeroClass::Rogue` (`1`) so the Barbarian displays the female Rogue portrait in hero selection and save menus.
- **File:** `Source/inv.cpp` — `InitInv()`
  - Mapped `HeroClass::Barbarian` to `data\inv\inv_rog` so the inventory paperdoll displays the female Rogue silhouette.

### 5.2 Rogue Sprites, Animations, Voice & Cinematics with Full Barbarian Mechanics
- **File:** `Source/playerdat.cpp`
  - Preserved all Barbarian stats and scaling (`baseStr=40, maxStr=255, baseMag=0, maxMag=0, baseDex=20, maxDex=55, baseVit=25, maxVit=150, blockBonus=30, itmLife=2.5x`, `SpellID::Rage`), innate resistance/two-handed weapon mastery, and starting equipment.
  - Mapped `PlayersData[HeroClass::Barbarian].classPath` to `"rogue"`, `PlayersSpriteData[HeroClass::Barbarian]` to Rogue sprite widths (`bow=128`), and `PlayersAnimData[HeroClass::Barbarian]` to match the Rogue `.cl2` directional frame counts (`18` sword/mace/unarmed, `22` axe, `12` bow, `8` idle/walk, `4` block, `20` death, `16` cast) while retaining fast Barbarian melee hit-frame timing (`actionFrame = 8..9`).
  - Replaced `herosounds[HeroClass::Barbarian]` with the female Rogue voice table (`PS_ROGUE1..PS_ROGUE102, PS_ROGUE71`).
- **File:** `Source/player.cpp` & `Source/engine/trn.cpp`
  - `GetPlayerSpriteClass(HeroClass::Barbarian)` unconditionally returns `HeroClass::Rogue` so `LoadPlrGFX()` loads `plrgfx\rogue\r*` `.cl2` sheets; `SetPlrAnims()` no longer applies the Warrior-only 15-frame armored death override to Barbarian; `GetClassTRN()` maps `HeroClass::Barbarian` to `plrgfx\rogue.trn`.
- **File:** `Source/effects.cpp`, `Source/objects.cpp` & `Source/monster.cpp`
  - `sound_init()` preloads `sfx_ROGUE` for `HeroClass::Barbarian` in Single Player; dungeon lore books and quest tomes (`AddCryptObject`, `OperateSChambBk`, `InitObjects`) use the Rogue's female voiceovers (`TEXT_RBOOKA..C`, `TEXT_RBONER`, `TEXT_RBLINDING`, `TEXT_RBLOODY`, `TEXT_RBLOODWAR`); defeating Diablo plays the female Rogue victory cinematic (`gendata\diabvic3.smk`).

---

## Phase 6: Na-Krul Death Freeze Fix, Defiler Monologue Suppression & Nest/Crypt Monster Roster Swap

### 6.1 Na-Krul Death Freeze & Item Packet Validation Fix (Crypt Level 24 Boss)
- **Root Cause (Freeze):** When `MT_NAKRUL` died (`Source/monster.cpp` — `SpawnLoot()`), it called `CreateSpellBook(monster.position.tile, SpellID::Apocalypse, sendmsg, false)`. In classic Diablo mode (`!gbIsHellfire`), `GetSpellBookLevel(SpellID::Apocalypse)` returns `-1`, meaning `SetupAllItems()` can never roll `SpellID::Apocalypse` on a generated book. Because `CreateSpellBook()` only checked `GetSpellBookLevel(ispell)` inside `if (gbIsHellfire)`, it spun in an infinite `while (true)` loop when `!gbIsHellfire`.
- **Root Cause (Invalid Packet Chat Message):** When `CreateMagicWeapon` and `SpawnItem` dropped items on Crypt Level 24 (`ItemsGetCurrlevel() == 17`, `ilvl == 34`, or `MT_NAKRUL` `mlvl == 40`), `NetSendCmdPItem` validated the loopback `CMD_DROPITEM` packet via `IsPItemValid()` -> `IsDungeonItemValid()` / `IsUniqueMonsterItemValid()` (`Source/items/validation.cpp`). Because `!gbIsHellfire` (`isHellfireItem == false`), `IsDungeonItemValid()` capped valid dungeon `ilvl` at `15 * 2 = 30` and skipped `MT_NAKRUL` (`MonsterAvailability::Never`), printing `"Player '<Name>' sent an invalid packet."` in the chat log.
- **File:** `Source/items.cpp` — `CreateSpellBook()` & `SpawnItem()`
  - Moved the `int bookLvl = GetSpellBookLevel(ispell); if (bookLvl < 0) return;` guard outside `if (gbIsHellfire)` so any unrollable spell book ID returns immediately instead of hanging in an infinite loop.
  - Included `MT_NAKRUL` alongside `MT_DIABLO` in `SpawnItem()` (`RndUItem(&monster)` and `uper = 15`).
- **File:** `Source/items/validation.cpp` — `IsUniqueMonsterItemValid()` & `IsDungeonItemValid()`
  - Allowed `MT_DIABLO`, `MT_NAKRUL`, `MT_DEFILER`, and `MT_HORKDMN` item levels in both `IsUniqueMonsterItemValid()` and `IsDungeonItemValid()`, and raised the dungeon container/weapon `ilvl` ceiling in `IsDungeonItemValid()` to `(24 - 7) * 2 = 34` unconditionally.
- **File:** `Source/monster.cpp` — `SpawnLoot()`
  - Updated `case MT_NAKRUL:` so when `!gbIsHellfire`, Na-Krul drops a standard boss item via `SpawnItem(monster, monster.position.tile, sendmsg)` instead of attempting to spawn Hellfire-only `SpellID::Apocalypse` and `Uber` items.

### 6.2 Suppress Defiler Quest Monologues on Hive Levels
- **File:** `Source/player.cpp` — `PlayDungMsgs()`
  - Removed the `currlevel == 17` (`USFX_DEFILER1` / `TEXT_DEFILER1`) and `currlevel == 19` (`USFX_DEFILER3` / `TEXT_DEFILER3`) branches so the Defiler's quest pop-up monologues never trigger on any Hive level.

### 6.3 Preserved Unused Vanilla Monster Families & Original Palettes
- **File:** `Source/monstdat.cpp` & `Source/monster.cpp`
  - **Spider Lord (`MT_ARACHNON`, `MT_SPIDLORD`):** Kept both variants in the Nest/Crypt roster and restored `MT_ARACHNON`'s sprite and palette from Hellfire's `wspidr\wspidr` back to the unused vanilla `bspidr\bspidr` (`MonsterAIID::Acid`, spitting acid projectiles and leaving an `AcidPuddle` on death).
  - **Torchant (`MT_TORCHANT`):** Kept in Crypt (`dLvl 21–23`) with its original unused vanilla `fireman\fireman` assets (`trnFile = nullptr`) and `Fireball` ranged attack.
  - **Bone Demon (`MT_SKLWING`, `MT_BONEDEMN`):** Kept both variants in Crypt (`dLvl 21–24`) and restored `MT_SKLWING`'s `trnFile` from `"monsters\\sklwing\\sklwx.trn"` to `nullptr` so both use their original vanilla `sklwing\sklwing` palette while keeping their `BoneDemon` projectile.
  - **Devil Kin Brute (`MT_BIGFALL`):** Kept in Crypt (`dLvl 21–22`) with its original unused vanilla `bigfall\bigfall` assets (`trnFile = nullptr`).
  - **Invisible Lord (`MT_FELLTWIN`, `MT_INVILORD`):** Kept `MT_FELLTWIN` (`dLvl 18–19`) and enabled `MT_INVILORD` (`MonsterAvailability::Retail`, `dLvl 22–23`, `soundSuffix = "newsfx\\ftwin"`) with their original unused vanilla `ftwin\ftwin` assets (`trnFile = nullptr`).
  - **Satyr Lord (`MT_LRDSAYTR`):** Kept in Crypt (`dLvl 22–24`) with its original unused vanilla `goatlrd\goatlrd` assets (`trnFile = nullptr`).

### 6.4 Matched Vanilla Monster Replacements & Preserved Hellfire Projectiles
- **File:** `Source/monstdat.cpp` & `Source/monster.cpp`
  - **Hive Casters -> Vanilla Magma Demons (`AiRangedAvoidance` with Hellfire Flare Projectiles):**
    - Replaced `MT_PSYCHORB` (`dLvl 17–18`) and `MT_NECRMORB` (`dLvl 19–20`) in the Hive with vanilla `magma\magma` `"Blood Stone"` (`magma\yellow.trn`) and `"Hell Stone"` (`magma\blue.trn`) models while preserving their `MonsterAIID::Psychorb` (`BlueFlare`) and `MonsterAIID::Necromorb` (`RedFlare`) projectiles via `AiRangedAvoidance`.
  - **Crypt Casters -> Vanilla Mages (`CounselorAi` with Hellfire Flare Projectiles):**
    - Replaced `MT_LICH` (*Lich*) and `MT_ARCHLICH` (*Arch-Lich*) in the Crypt with vanilla `mage\mage` Counselor/Advocate models and palettes (`nullptr`, `mage\cnselbk.trn`) while routing `Lich` and `ArchLich` AIs through `CounselorAi` (`Source/monster.cpp`) with `GetMissileType(monster.ai)` (`OrangeFlare`, `YellowFlare`).
  - **Hellfire Bats -> Vanilla Bats with Firebolt/Fireball Projectiles:**
    - Replaced `MT_FIREBAT` and `MT_HELLBAT` with vanilla `bat\bat` (`Blink` / `Gloom` palettes) while keeping `MonsterAIID::Firebat` (`Firebolt`) and `MonsterAIID::Hellbat` (`Fireball`).
  - **Remaining Nest & Crypt Monster Replacements:**
    - `MT_UNRAV` -> `"Illusion Weaver"` (`sneak\sneak`, `sneakv1.trn`, `MonsterAIID::Sneak`)
    - `MT_HELLBOAR` -> `"Obsidian Lord"` (`rhino\rhino`, `rhinob.trn`, `MonsterAIID::Rhino`)
    - `MT_STINGER` -> `"Fire Drake"` (`snake\snake`, `snakr.trn`, `MonsterAIID::Snake`)
    - `MT_HORKSPWN` -> `"Lava Maw"` (`acid\acid`, `acidr.trn`, `MonsterAIID::Acid`)
    - `MT_VENMTAIL` -> `"Azure Drake"` (`snake\snake`, `snakb.trn`, `MonsterAIID::Snake`)
    - `MT_LASHWORM` -> `"Maelstrom"` (`thin\thin`, `thinv1.trn`, `MonsterAIID::Storm`)
    - `MT_HORKDMN` -> `"Balrog"` (`mega\mega`, `balr.trn`, `MonsterAIID::SkeletonMelee`)
    - `MT_GRAVEDIG` -> `"Bone Gasher"` (`scav\scav`, `scavw.trn`, `MonsterAIID::Scavenger`)
    - `MT_TOMBRAT` -> `"Horror Captain"` (`skelsd\sklsr`, `black.trn`, `MonsterAIID::SkeletonMelee`)
    - `MT_CRYPTDMN` -> `"Lava Lord"` (`magma\magma`, `wierd.trn`, `MonsterAIID::Magma`)
    - `MT_BICLOPS` -> `"Flayed One"` (`fat\fat`, `fatf.trn`, `MonsterAIID::SkeletonMelee`)
    - `MT_FLESTHNG` -> `"Black Death"` (`zombie\zombie`, `yellow.trn`, `MonsterAIID::SkeletonMelee`)
    - `MT_REAPER` -> `"Blood Knight"` (`black\black`, `blkkntbe.trn`, `MonsterAIID::SkeletonMelee`)
  - Updated `AddMonsterType()` in `Source/monster.cpp` to preload `MagmaBall`, `ThinLightning`, and `Acid`/`AcidPuddle` missile graphics whenever `monsterData.ai` is `Magma`, `Storm`, or `Acid`.

---

## Phase 7: OpenAL Soft + EFX Extension, 3D Surround, Binaural HRTF & Wall Occlusion

### 7.1 Static OpenAL Soft 1.23.1 Backend & Embedded HRTF Dataset
- **File:** `Source/CMakeLists.txt`
  - Statically linked `OpenAL::OpenAL` (`libOpenAL32.a` built with `ALSOFT_EMBED_HRTF_DATA=ON`, `ole32`, `uuid`, `winmm`) into `libdevilutionx` so `dx-eternity.exe` remains a single self-contained executable with embedded HRTF filters and full WASAPI/DirectSound/WinMM support.
- **File:** `Source/options.h` & `Source/options.cpp`
  - Raised `DEFAULT_AUDIO_SAMPLE_RATE` from `22050` to `48000` Hz and added in-game Audio Options toggles for **EFX Reverb** (`efxReverb`, default `ON`) and **Binaural HRTF** (`hrtf`, default `ON`).

### 7.2 EFX Environmental Reverb Presets (`ALC_EXT_EFX` / `AL_EFFECT_EAXREVERB`) & Wall Occlusion
- **File:** `Source/engine/sound.h` & `Source/engine/sound.cpp`
  - Initialized an OpenAL Soft context (`ALC_STEREO_MODE_SOFT = ALC_EXTENDED_SOFT`, `ALC_HRTF_SOFT`, `ALC_MAX_AUXILIARY_SENDS = 2`) and EFX Auxiliary Effect Slot (`gEfxSlot`) backed by `AL_EFFECT_EAXREVERB`.
  - Implemented `UpdateSoundEnvironment(dungeon_type)` using `<AL/efx-presets.h>` to dynamically reconfigure the EFX reverb tank per area:
    - **Town (`DTYPE_TOWN`):** `EFX_REVERB_PRESET_OUTDOORS_BACKYARD` (subtle open-air reflections)
    - **Cathedral (`DTYPE_CATHEDRAL`):** `EFX_REVERB_PRESET_CHAPEL` (Gothic stone arches & vaulted ceiling)
    - **Catacombs (`DTYPE_CATACOMBS`):** `EFX_REVERB_PRESET_STONEROOM` (enclosed subterranean tombs)
    - **Caves (`DTYPE_CAVES`):** `EFX_REVERB_PRESET_CAVE` (echoing natural rock caverns)
    - **Hell (`DTYPE_HELL`):** `EFX_REVERB_PRESET_CATHEDRAL` (`flDecayTime = 3.5s`, `flDecayLFRatio = 1.25` — deep abyssal hall)
    - **Hive (`DTYPE_NEST`):** `EFX_REVERB_PRESET_CAVE` (`flDecayTime = 1.5s`, `flDecayHFRatio = 0.35` — dampened organic tunnels)
    - **Crypt (`DTYPE_CRYPT`):** `EFX_REVERB_PRESET_AUDITORIUM` (`flDecayTime = 3.1s`, `flDecayHFRatio = 0.92` — resonant stone crypt)
  - Created EFX Low-Pass Filters (`gFilterOccludedDirect`: `AL_LOWPASS_GAIN = 0.58f, AL_LOWPASS_GAINHF = 0.22f`; `gFilterOccludedSend`: `AL_LOWPASS_GAIN = 0.85f, AL_LOWPASS_GAINHF = 0.45f`) applied whenever a dungeon sound's line-of-sight to the player (`LineClear(IsTileNotSolid, ...)`) is blocked by solid walls.

### 7.3 Shared `ALuint` Buffers & Isometric 3D Spatialization (`AL_SOFT_source_spatialize`)
- **File:** `Source/utils/soundsample.h`, `Source/utils/soundsample.cpp` & `Source/effects.cpp`
  - Decoded WAV/MP3 sound effects into shared `OpenAlBuffer` (`ALuint`) objects so `DuplicateFrom()` shares the decoded PCM buffer in `O(1)` without re-decoding or allocating resamplers.
  - Mapped isometric tile offsets `(deltaX, deltaY)` into listener-relative 3D space with an elevated listener depth offset (`z = isoY * 0.75f - 2.2f`) and enabled `AL_SOURCE_SPATIALIZE_SOFT = AL_TRUE` so both mono and stereo SFX spatialize smoothly across 5.1/7.1 surround speakers and binaural HRTF headphones without harsh 180° front/back flips in melee range.


